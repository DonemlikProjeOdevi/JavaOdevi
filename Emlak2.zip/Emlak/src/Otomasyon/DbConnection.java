package Otomasyon;
import static Otomasyon.İlanListesi.ilanlartablo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class DbConnection {
     static Statement st;
     static Connection con;
      String query ;
      ResultSet rs;
      //vtbaglanti
    public void Connect()
    {
         try {
          Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url="jdbc:sqlserver://localhost:1433;databaseName=Emlak;user=;password=;integratedSecurity=true;";
        con = DriverManager.getConnection(url);    
        st = con.createStatement();
        System.out.println("Connecting");
        }
         catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
        }

        
    }
  
  public boolean IsUser(String uname,String pw)
  {
      // sorgu cümlesi
      query = "SELECT * FROM Yetkililer where username='"+uname+"' and userpassword='"+pw+"'";
     
      try
      {
          //veri setine gelen sonucları ekler
          rs=st.executeQuery(query);
          //veri seti icinde sırayla degerleri gezer
          if(rs.next())
          {
             System.out.println("ok");
             return true;
          }
          else 
          {
              System.out.println("false");
            return false;
          }
      }
    catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
   
        }
return false;
  }
  
  public boolean ilanEkle(String ilansahip,String gsm,String tur,int aktif,String Aciklama)
  {
        query = "INSERT INTO İlanlar VALUES('"+tur+"','"+Aciklama+"','"+aktif+"','"+ilansahip+"','"+gsm+"')";
     
      try
      {
        
        st.executeUpdate(query);
        return true;
          
      }
    catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
   return false;
        }
      
  }
  
  public void ilanlarListesi()
  {
         try{
        String sql= "SELECT *FROM İlanlar where ilandurumu='1'";
         rs=st.executeQuery(sql);
         İlanListesi.ilanlartablo.setModel(DbUtils.resultSetToTableModel(rs));
         
    }catch(Exception e){
        System.out.println(e);
       
    }
  }
  public void eskiilanlarListesi()
  {
         try{
        String sql= "SELECT *FROM İlanlar where ilandurumu='0'";
         rs=st.executeQuery(sql);
         Gecmisİlanlar.gecmisilanlartablo.setModel(DbUtils.resultSetToTableModel(rs));
         
    }catch(Exception e){
        System.out.println(e);
       
    }
  }
  public void aktifİlanListesi()
  {
         try{
        String sql= "SELECT *FROM İlanlar where ilandurumu='1'";
         rs=st.executeQuery(sql);
         İlanKapatma.aktifilantablo.setModel(DbUtils.resultSetToTableModel(rs));
         
    }catch(Exception e){
        System.out.println(e);
       
    }
  }
  public void musterisecTablo()
      {
           {
         try{
        String sql= "SELECT *FROM musteriler Where durum=1 ";
         rs=st.executeQuery(sql);
         İlanKapatma.musteritablo.setModel(DbUtils.resultSetToTableModel(rs));
         
    }catch(Exception e){
        System.out.println(e);
       
    }
  }
      }
  public boolean ilanKapat(String ilanid,String musterid)
  {
        query = "UPDATE İlanlar SET musteriid="+musterid+",ilandurumu='0' Where ilanid="+ilanid;
        String query2="UPDATE Musteriler SET durum=0"+"Where musteriid="+musterid;
     
      try
      {
        
        st.executeUpdate(query);
        st.executeUpdate(query2);
        return true;
          
      }
    catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
   return false;
        }
      
  }
  public boolean musteriEkle(String ad,String soyad,String telefon,int durum)
  {
        query = "INSERT INTO Musteriler VALUES('"+ad+"','"+soyad+"','"+telefon+"','"+durum+"')";
     
      try
      {
        
        st.executeUpdate(query);
        return true;
          
      }
    catch(Exception e){
            JOptionPane.showMessageDialog(null,e);
   return false;
        }
      
  }
    public void musteriListeTablo()
      {
           {
         try{
        String sql= "SELECT *FROM musteriler ";
         rs=st.executeQuery(sql);
         TumMusteriler.tummusterilertablo.setModel(DbUtils.resultSetToTableModel(rs));
         
    }catch(Exception e){
        System.out.println(e);
       
    }
  }
      }
     public void bekleyenmusteriListeTablo()
      {
           {
         try{
        String sql= "SELECT *FROM musteriler Where durum=1 ";
         rs=st.executeQuery(sql);
         BekleyenMusteriler.bekleyenmusteritablo.setModel(DbUtils.resultSetToTableModel(rs));
         
    }catch(Exception e){
        System.out.println(e);
       
    }
  }
      }
}

