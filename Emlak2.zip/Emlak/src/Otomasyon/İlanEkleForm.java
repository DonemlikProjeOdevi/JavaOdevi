
package Otomasyon;

import javax.swing.JOptionPane;

public class İlanEkleForm extends javax.swing.JFrame {
int ilanaktif=1;
    public İlanEkleForm() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Container = new javax.swing.JPanel();
        headerlabel = new javax.swing.JLabel();
        yeniilan1 = new javax.swing.JButton();
        sahip = new javax.swing.JTextField();
        gsm = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        aciklama = new javax.swing.JTextArea();
        aktifmi = new javax.swing.JCheckBox();
        turliste = new javax.swing.JSpinner();
        headerlabel1 = new javax.swing.JLabel();
        headerlabel2 = new javax.swing.JLabel();

        setResizable(false);

        Container.setBackground(new java.awt.Color(12, 49, 65));

        headerlabel.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        headerlabel.setForeground(java.awt.SystemColor.controlHighlight);
        headerlabel.setText("İlan Sahibi GSM No");

        yeniilan1.setBackground(new java.awt.Color(11, 232, 129));
        yeniilan1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        yeniilan1.setForeground(java.awt.Color.white);
        yeniilan1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Otomasyon/icons/icons8_add_48px.png"))); // NOI18N
        yeniilan1.setText("Yeni İlan Ekle");
        yeniilan1.setToolTipText("");
        yeniilan1.setBorder(null);
        yeniilan1.setBorderPainted(false);
        yeniilan1.setFocusPainted(false);
        yeniilan1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        yeniilan1.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        yeniilan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yeniilan1ActionPerformed(evt);
            }
        });

        sahip.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        sahip.setToolTipText("İlan Sahibi Ad Soyad");

        gsm.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        aciklama.setColumns(5);
        aciklama.setFont(new java.awt.Font("Monospaced", 0, 18)); // NOI18N
        aciklama.setRows(1);
        aciklama.setText("İlan Açıklaması");
        jScrollPane1.setViewportView(aciklama);

        aktifmi.setSelected(true);
        aktifmi.setText("Aktif İlan");
        aktifmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aktifmiActionPerformed(evt);
            }
        });

        turliste.setModel(new javax.swing.SpinnerListModel(new String[] {"Kiralik Ev", "Satılık Ev", "Kiralık Dükkan", "Satılık Dükkan", "Satılık Arsa"}));

        headerlabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        headerlabel1.setForeground(java.awt.SystemColor.controlHighlight);
        headerlabel1.setText("Yeni İlan Ekle");

        headerlabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        headerlabel2.setForeground(java.awt.SystemColor.controlHighlight);
        headerlabel2.setText("İlan Sahibi Ad Soyad");

        javax.swing.GroupLayout ContainerLayout = new javax.swing.GroupLayout(Container);
        Container.setLayout(ContainerLayout);
        ContainerLayout.setHorizontalGroup(
            ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContainerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(ContainerLayout.createSequentialGroup()
                        .addComponent(turliste, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(aktifmi, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 444, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(ContainerLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(yeniilan1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ContainerLayout.createSequentialGroup()
                        .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(sahip, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(ContainerLayout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(headerlabel1)
                                    .addComponent(headerlabel2))))
                        .addGap(119, 119, 119)
                        .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(headerlabel)
                            .addComponent(gsm, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ContainerLayout.setVerticalGroup(
            ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(headerlabel1)
                .addGap(37, 37, 37)
                .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(headerlabel)
                    .addComponent(headerlabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sahip, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gsm, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(ContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(aktifmi, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(turliste, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(yeniilan1)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Container, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Container, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void yeniilan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yeniilan1ActionPerformed
        DbConnection db = new DbConnection();
        if(db.ilanEkle(sahip.getText(),gsm.getText(),turliste.getValue().toString(),ilanaktif, aciklama.getText()))
        {
            JOptionPane.showMessageDialog(null,"İlan Eklendi");
        }
    }//GEN-LAST:event_yeniilan1ActionPerformed

    private void aktifmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aktifmiActionPerformed
    if(aktifmi.isSelected()==true) ilanaktif=1;
    else ilanaktif=0;
    System.out.println(ilanaktif);
    
        // TODO add your handling code here:
    }//GEN-LAST:event_aktifmiActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(İlanEkleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(İlanEkleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(İlanEkleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(İlanEkleForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new İlanEkleForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Container;
    private javax.swing.JTextArea aciklama;
    private javax.swing.JCheckBox aktifmi;
    private javax.swing.JTextField gsm;
    private javax.swing.JLabel headerlabel;
    private javax.swing.JLabel headerlabel1;
    private javax.swing.JLabel headerlabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField sahip;
    private javax.swing.JSpinner turliste;
    private javax.swing.JButton yeniilan1;
    // End of variables declaration//GEN-END:variables
}
