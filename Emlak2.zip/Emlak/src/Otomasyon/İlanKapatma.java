package Otomasyon;

import javax.swing.JOptionPane;


public class İlanKapatma extends javax.swing.JFrame {

   int secilenilanid;
   int secilenmusteriid;
    public İlanKapatma() {
        initComponents();
     DbConnection db=new DbConnection();
      db.aktifİlanListesi();
      db.musterisecTablo();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        aktifilantablo = new javax.swing.JTable();
        musteribox = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        musteritablo = new javax.swing.JTable();
        hosgeldiniizlabel = new javax.swing.JLabel();
        ilantxtbox = new javax.swing.JTextField();
        hosgeldiniizlabel1 = new javax.swing.JLabel();
        yeniilan = new javax.swing.JButton();
        hosgeldiniizlabel2 = new javax.swing.JLabel();
        hosgeldiniizlabel3 = new javax.swing.JLabel();

        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(12, 49, 65));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(12, 49, 65));

        jScrollPane1.setBackground(new java.awt.Color(12, 49, 65));

        aktifilantablo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        aktifilantablo.setCellSelectionEnabled(true);
        aktifilantablo.setEditingColumn(0);
        aktifilantablo.setEditingRow(0);
        aktifilantablo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aktifilantabloMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                aktifilantabloMouseEntered(evt);
            }
        });
        jScrollPane1.setViewportView(aktifilantablo);
        aktifilantablo.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        musteribox.setEditable(false);

        jScrollPane2.setBackground(new java.awt.Color(12, 49, 65));

        musteritablo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        });
        musteritablo.setCellSelectionEnabled(true);
        musteritablo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                musteritabloMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(musteritablo);
        musteritablo.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        hosgeldiniizlabel.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        hosgeldiniizlabel.setForeground(java.awt.SystemColor.controlHighlight);
        hosgeldiniizlabel.setText("Seçilen İlan Kodu");

        ilantxtbox.setEditable(false);

        hosgeldiniizlabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        hosgeldiniizlabel1.setForeground(java.awt.SystemColor.controlHighlight);
        hosgeldiniizlabel1.setText("Seçilen Müşteir");

        yeniilan.setBackground(new java.awt.Color(216, 112, 169));
        yeniilan.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        yeniilan.setForeground(java.awt.Color.white);
        yeniilan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Otomasyon/icons/icons8_close_all_tabs_48px.png"))); // NOI18N
        yeniilan.setText("İlan Kapatma");
        yeniilan.setToolTipText("");
        yeniilan.setBorder(null);
        yeniilan.setBorderPainted(false);
        yeniilan.setFocusPainted(false);
        yeniilan.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        yeniilan.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        yeniilan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yeniilanActionPerformed(evt);
            }
        });

        hosgeldiniizlabel2.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        hosgeldiniizlabel2.setForeground(java.awt.SystemColor.controlHighlight);
        hosgeldiniizlabel2.setText("Aktif İlanlar");

        hosgeldiniizlabel3.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        hosgeldiniizlabel3.setForeground(java.awt.SystemColor.controlHighlight);
        hosgeldiniizlabel3.setText("Aktif Müşteriler");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(yeniilan, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(musteribox, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(143, 143, 143)
                        .addComponent(ilantxtbox, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(hosgeldiniizlabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(hosgeldiniizlabel)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(hosgeldiniizlabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(hosgeldiniizlabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 10, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hosgeldiniizlabel2)
                    .addComponent(hosgeldiniizlabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(hosgeldiniizlabel1)
                        .addGap(20, 20, 20)
                        .addComponent(musteribox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(hosgeldiniizlabel)
                        .addGap(18, 18, 18)
                        .addComponent(ilantxtbox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(yeniilan, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void yeniilanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yeniilanActionPerformed
    if(ilantxtbox.getText().length()!=0 && musteribox.getText().length()!=0) 
{
    DbConnection update=new DbConnection();
    try
    {
        update.ilanKapat(ilantxtbox.getText(), musteribox.getText());
        JOptionPane.showMessageDialog(null, "0İlan Başarıyla Kapatıldı");
        this.setVisible(false);
    }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(null, e);
    }
}
    else JOptionPane.showMessageDialog(null, "ilan veya müşteri seçilmedi");
    }//GEN-LAST:event_yeniilanActionPerformed

    private void musteritabloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_musteritabloMouseClicked
JOptionPane.showMessageDialog(null,"Müşteri Seçildi");
   musteribox.setText(musteritablo.getModel().getValueAt(musteritablo.getSelectedRow(),0).toString());
    }//GEN-LAST:event_musteritabloMouseClicked

    private void aktifilantabloMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aktifilantabloMouseEntered

    }//GEN-LAST:event_aktifilantabloMouseEntered

    private void aktifilantabloMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aktifilantabloMouseClicked
   JOptionPane.showMessageDialog(null,"İlan Seçildi");
   ilantxtbox.setText(aktifilantablo.getModel().getValueAt(aktifilantablo.getSelectedRow(),0).toString());
    }//GEN-LAST:event_aktifilantabloMouseClicked

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(İlanKapatma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(İlanKapatma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(İlanKapatma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(İlanKapatma.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new İlanKapatma().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTable aktifilantablo;
    private javax.swing.JLabel hosgeldiniizlabel;
    private javax.swing.JLabel hosgeldiniizlabel1;
    private javax.swing.JLabel hosgeldiniizlabel2;
    private javax.swing.JLabel hosgeldiniizlabel3;
    private javax.swing.JTextField ilantxtbox;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField musteribox;
    public static javax.swing.JTable musteritablo;
    private javax.swing.JButton yeniilan;
    // End of variables declaration//GEN-END:variables
}
